
package zimovets.igor.com.vidmeclient.data.model.video;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Watching {

    @SerializedName("18161760")
    @Expose
    private Integer _18161760;
    @SerializedName("18166518")
    @Expose
    private Integer _18166518;
    @SerializedName("18168033")
    @Expose
    private Integer _18168033;

    public Integer get18161760() {
        return _18161760;
    }

    public void set18161760(Integer _18161760) {
        this._18161760 = _18161760;
    }

    public Integer get18166518() {
        return _18166518;
    }

    public void set18166518(Integer _18166518) {
        this._18166518 = _18166518;
    }

    public Integer get18168033() {
        return _18168033;
    }

    public void set18168033(Integer _18168033) {
        this._18168033 = _18168033;
    }

}
